package com.birdeye.ambtools;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.hc.client5.http.config.RequestConfig;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.*;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import jakarta.annotation.PostConstruct;
import java.io.IOException;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import static org.apache.hc.core5.util.TimeValue.ofMilliseconds;

@RestController
@RequestMapping("/ambassador/admin")
public class ProxyController {

    private static final Logger log = LoggerFactory.getLogger(ProxyController.class);
    private static final ObjectMapper MAPPER = new ObjectMapper();
    private static final int TIMEOUT_MS = 30000;

    private RestTemplate restTemplate;

    @PostConstruct
    private void init() {
        RequestConfig requestConfig = RequestConfig.custom()
                .setConnectionRequestTimeout(TIMEOUT_MS, TimeUnit.MILLISECONDS)
                .setConnectTimeout(TIMEOUT_MS, TimeUnit.MILLISECONDS)
                .setResponseTimeout(TIMEOUT_MS, TimeUnit.MILLISECONDS)
                .build();

        PoolingHttpClientConnectionManager connManager = new PoolingHttpClientConnectionManager();
        connManager.setMaxTotal(50);
        connManager.setDefaultMaxPerRoute(20);
        connManager.setValidateAfterInactivity(ofMilliseconds(300));

        CloseableHttpClient httpClient = HttpClients.custom()
                .setConnectionManager(connManager)
                .setDefaultRequestConfig(requestConfig)
                .build();

        this.restTemplate = new RestTemplate(new HttpComponentsClientHttpRequestFactory(httpClient));
    }

    @GetMapping(path = "/tools", produces = MediaType.TEXT_HTML_VALUE)
    public ResponseEntity<String> serveIndex() throws IOException {
        return serveHtml("static/tools-index.html");
    }

    @GetMapping(path = "/curl-builder-tool", produces = MediaType.TEXT_HTML_VALUE)
    public ResponseEntity<String> serveCurlBuilder() throws IOException {
        return serveHtml("static/curl-builder-tool.html");
    }

    @GetMapping(path = "/generic-api-config-tool", produces = MediaType.TEXT_HTML_VALUE)
    public ResponseEntity<String> serveGenericApiConfig() throws IOException {
        return serveHtml("static/generic-api-config-tool.html");
    }

    @GetMapping(path = "/ops-tool", produces = MediaType.TEXT_HTML_VALUE)
    public ResponseEntity<String> serveOpsTool() throws IOException {
        return serveHtml("static/ops-tool.html");
    }

    @GetMapping(path = "/developer-portal-tool", produces = MediaType.TEXT_HTML_VALUE)
    public ResponseEntity<String> serveDeveloperPortal() throws IOException {
        return serveHtml("static/developer-portal-tool.html");
    }

    @PostMapping(path = "/tools/proxy", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Map<String, Object>> proxy(@RequestBody Map<String, Object> request) {
        String targetUrl = (String) request.get("targetUrl");
        String method = (String) request.getOrDefault("method", "POST");
        Object payload = request.get("payload");
        String rawBody = (String) request.get("rawBody");
        @SuppressWarnings("unchecked")
        Map<String, String> customHeaders = (Map<String, String>) request.get("headers");

        if (targetUrl == null) {
            return ResponseEntity.badRequest().body(Map.of("error", "Missing targetUrl"));
        }

        URI uri;
        try {
            uri = URI.create(targetUrl);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", "Invalid targetUrl"));
        }

        log.info("[PROXY] {} {}", method, targetUrl);

        try {
            HttpHeaders headers = new HttpHeaders();
            headers.set("Accept", "application/json");
            headers.set("Cache-Control", "no-cache");
            if (customHeaders != null) customHeaders.forEach(headers::set);

            HttpMethod httpMethod;
            HttpEntity<String> httpEntity;

            if ("GET".equalsIgnoreCase(method)) {
                httpMethod = HttpMethod.GET;
                httpEntity = new HttpEntity<>(headers);
            } else if ("PUT".equalsIgnoreCase(method)) {
                httpMethod = HttpMethod.PUT;
                headers.setContentType(MediaType.APPLICATION_JSON);
                httpEntity = new HttpEntity<>(rawBody != null ? rawBody : serialize(payload), headers);
            } else if ("DELETE".equalsIgnoreCase(method)) {
                httpMethod = HttpMethod.DELETE;
                httpEntity = new HttpEntity<>(headers);
            } else {
                httpMethod = HttpMethod.POST;
                headers.setContentType(MediaType.APPLICATION_JSON);
                httpEntity = new HttpEntity<>(rawBody != null ? rawBody : serialize(payload), headers);
            }

            ResponseEntity<String> resp = restTemplate.exchange(uri, httpMethod, httpEntity, String.class);
            log.info("[PROXY] Response {} from {}", resp.getStatusCode().value(), uri.getHost());

            return ResponseEntity.ok(Map.of(
                    "status", resp.getStatusCode().value(),
                    "statusText", HttpStatus.valueOf(resp.getStatusCode().value()).getReasonPhrase(),
                    "body", resp.getBody() != null ? resp.getBody() : ""
            ));
        } catch (ResourceAccessException e) {
            log.warn("[PROXY] Timeout/connection error: {}", e.getMostSpecificCause().getMessage());
            return ResponseEntity.status(HttpStatus.GATEWAY_TIMEOUT)
                    .body(Map.of("error", "Request failed: " + e.getMostSpecificCause().getMessage()));
        } catch (Exception e) {
            log.error("[PROXY] Error: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_GATEWAY)
                    .body(Map.of("error", e.getMessage()));
        }
    }

    private String serialize(Object payload) throws Exception {
        if (payload == null) return "{}";
        if (payload instanceof String s) return s;
        return MAPPER.writeValueAsString(payload);
    }

    private ResponseEntity<String> serveHtml(String path) throws IOException {
        ClassPathResource resource = new ClassPathResource(path);
        String html = resource.getContentAsString(StandardCharsets.UTF_8);
        return ResponseEntity.ok(html);
    }
}
