package com.birdeye.ambtools;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

@SpringBootApplication
public class AmbToolsApplication {
    public static void main(String[] args) {
        SpringApplication.run(AmbToolsApplication.class, args);
    }
}

@Component
class BrowserLauncher {
    private static final String URL = "http://localhost:7337/ambassador/admin/tools";

    @EventListener(ApplicationReadyEvent.class)
    public void openBrowser() {
        try {
            String os = System.getProperty("os.name").toLowerCase();
            Runtime rt = Runtime.getRuntime();
            if (os.contains("mac")) {
                rt.exec(new String[]{"open", URL});
            } else if (os.contains("win")) {
                rt.exec(new String[]{"rundll32", "url.dll,FileProtocolHandler", URL});
            } else {
                rt.exec(new String[]{"xdg-open", URL});
            }
        } catch (Exception e) {
            System.out.println("\n>>> Open your browser at: " + URL + "\n");
        }
    }
}
