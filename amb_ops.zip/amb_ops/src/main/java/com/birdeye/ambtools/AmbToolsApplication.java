package com.birdeye.ambtools;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AmbToolsApplication {
    public static void main(String[] args) {
        SpringApplication.run(AmbToolsApplication.class, args);
    }
}
